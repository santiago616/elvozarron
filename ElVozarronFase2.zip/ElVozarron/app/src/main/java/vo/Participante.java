package vo;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Clase Participante
 * Created by santiago on 23/10/16.
 */
public class Participante implements Parcelable {
    //Declaracion de atributos de tipo String cuyos identificadores son: identificacion,nombre,relacionUniversidad,urlVIdeo,estado,numeroVotos,edad
    private String identificacion,nombre,relacionUniversidad,urlVideo,estado,numeroVotos,edad;


    /**
     * Metodo constructor de la clase
     * @param identificacion instancia de la identificacion
     * @param nombre instancia del nombre
     * @param edad instancia de la edad
     * @param urlVideo instancia de urlVIdeo
     * @param relacionUniversidad instancia de la relacionUniversidad
     * @param estado instancia del estado
     * @param numeroVotos instancia del numeroVotos
     */
    public Participante(String identificacion, String nombre, String edad, String urlVideo, String relacionUniversidad, String estado, String numeroVotos) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.edad = edad;
        this.urlVideo = urlVideo;
        this.relacionUniversidad = relacionUniversidad;
        this.estado = estado;
        this.numeroVotos = numeroVotos;
    }

    /**
     * Metodo constructor creado al implementar Parcelable
     * @param in
     */
    protected Participante(Parcel in) {
        identificacion = in.readString();
        nombre = in.readString();
        edad = in.readString();
        urlVideo = in.readString();
        relacionUniversidad=in.readString();
        estado=in.readString();
        numeroVotos=in.readString();
    }

    /**
     * Metodo creado al implementar Parcelable
     * @param dest
     * @param flags
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(identificacion);
        dest.writeString(nombre);
        dest.writeString(edad);
        dest.writeString(urlVideo);
        dest.writeString(relacionUniversidad);
        dest.writeString(estado);
        dest.writeString(numeroVotos);



    }
    /**
     * Metodo creator que se crea al implementar Parcelable
     */
    public static final Creator<Participante> CREATOR = new Creator<Participante>() {
        @Override
        public Participante createFromParcel(Parcel in) {
            return new Participante(in);
        }

        @Override
        public Participante[] newArray(int size) {
            return new Participante[size];
        }
    };



//Metodos get y set de la aplicacion
    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getRelacionUniversidad() {
        return relacionUniversidad;
    }

    public void setRelacionUniversidad(String relacionUniversidad) {
        this.relacionUniversidad = relacionUniversidad;
    }

    public String getUrlVideo() {
        return urlVideo;
    }

    public void setUrlVideo(String urlVideo) {
        this.urlVideo = urlVideo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getNumeroVotos() {
        return numeroVotos;
    }

    public void setNumeroVotos(String numeroVotos) {
        this.numeroVotos = numeroVotos;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    //Metodos get y set de la aplicacion


}
