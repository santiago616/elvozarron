package vo;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Clase Entrenador
 * Created by santiago on 25/10/16.
 */
public class Entrenador implements Parcelable{

    //Declaracion de atributos de tipo String cuyos identificadores son: identificacion,nombre,genero,historial
    private String identificacion,nombre,genero,historial;

    /**
     * Metodo constructor de la clase
     * @param identificacion instancia de la identificacion
     * @param nombre instancia del nombre
     * @param genero instancia del genero
     * @param historial instancia del historial
     */

    public Entrenador(String identificacion, String nombre, String genero, String historial) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.genero = genero;
        this.historial = historial;
    }

    /**
     * Metodo Constructor de tipo protected que se crea al implementar Parcelable
     * @param in
     */
    protected Entrenador(Parcel in) {
        identificacion = in.readString();
        nombre = in.readString();
        genero = in.readString();
        historial = in.readString();
    }

    /**
     * Metodo WriteTo Parcel creado al implementar Parcelable
     * @param dest
     * @param flags
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(identificacion);
        dest.writeString(nombre);
        dest.writeString(genero);
        dest.writeString(historial);
    }

    /**
     * Metodo creator que se crea al implementar Parcelable
     */
    public static final Creator<Entrenador> CREATOR = new Creator<Entrenador>() {
        @Override
        public Entrenador createFromParcel(Parcel in) {
            return new Entrenador(in);
        }

        @Override
        public Entrenador[] newArray(int size) {
            return new Entrenador[size];
        }
    };

//Metodos get y set de la aplicacion
    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getHistorial() {
        return historial;
    }

    public void setHistorial(String historial) {
        this.historial = historial;
    }

    @Override
    public int describeContents() {
        return 0;
    }
//Metodos get y set de la aplicacion


}
