package fragments;


import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import co.edu.uniquindio.android.electiva.elvozarron.R;
import vo.Participante;

/**
 * Clase que permite mostrar los detalles de los participantes en la aplicacion
 * A simple {@link Fragment} subclass.
 */
public class DetallesDeParticipanteFragment extends Fragment implements View.OnClickListener {


    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtIdentificacion;
    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtNombre;
    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtEdad;
    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtUrlVideo;
    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtRelacionUniversidad;
    //Declaracion de Atributo de tipo Personaje cuyo identificador es personaje
    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtEstado;
    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtNumeroVotos;
    //Declaracion de Atributo de tipo Button cuyo identificador es btnIrVIdeo
    private Button btnIrVideo;
    //Declaracion de Atributo de tipo Participante cuyo identificador es participante
    private Participante participante;

    /**
     * Metodo constructor de la clase
     */
    public DetallesDeParticipanteFragment() {
        // Required empty public constructor
    }

    /**
     * Metodo que muestra todos los datos del participante en pantalla en las cajas de texto
     * al igual que la imagen de cada uno de ellos
     * @param inflater parametro que permite inflar el layout con el layout que se quiere mostrar
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detalle_de_participante, container, false);
    }


    /**
     * Metodo que muestra todos los datos del participante en pantalla en las cajas de texto
     * al igual que la imagen de cada uno de ellos
     * @param participante participante que se desea visualizar
     */
    public void mostrarParticipante (Participante participante) {
        this.participante = participante;

        txtIdentificacion = (TextView)
                getView().findViewById(R.id.identificacion_participante);
        txtIdentificacion.setText("Identificacion: "+participante.getIdentificacion());


        txtNombre = (TextView)
                getView().findViewById(R.id.nombre_participante);
        txtNombre.setText("Nombre: "+participante.getNombre());



      txtEdad = (TextView)
               getView().findViewById(R.id.edad_participante);
       txtEdad.setText("Edad: "+participante.getEdad());

        btnIrVideo = (Button)
                getView().findViewById(R.id.btn_ir_a_video);
        btnIrVideo.setOnClickListener(this);


          txtRelacionUniversidad = (TextView)
                  getView().findViewById(R.id.relacionuniversidad_participante);
          txtRelacionUniversidad.setText("Relacion Universidad: " +participante.getRelacionUniversidad());

        txtEstado = (TextView)
                getView().findViewById(R.id.estado_participante);
         txtEstado.setText("Estado: "+participante.getEstado());

         txtNumeroVotos = (TextView)
                 getView().findViewById(R.id.votos_participante);
         txtNumeroVotos.setText("Numero de Votos: "+participante.getNumeroVotos());



    }

    /**
     * Metodo que permite que cuando se pulse el boton se abra una ventana de navegacion y muestre el video
     * @param v
     */
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse(participante.getUrlVideo()));
        startActivity(intent);
    }
    //Metodos get y set de la aplicacion
    public TextView getTxtNombre() {
        return txtNombre;
    }

    public void setTxtNombre(TextView txtNombre) {
        this.txtNombre = txtNombre;
    }

    public Participante getParticipante() {
        return participante;
    }

    public void setParticipante(Participante participante) {
        this.participante = participante;
    }

    public TextView getTxtIdentificacion() {
        return txtIdentificacion;
    }

    public void setTxtIdentificacion(TextView txtIdentificacion) {
        this.txtIdentificacion = txtIdentificacion;
    }

    public TextView getTxtEdad() {
        return txtEdad;
    }

    public void setTxtEdad(TextView txtEdad) {
        this.txtEdad = txtEdad;
    }

    public TextView getTxtUrlVideo() {
        return txtUrlVideo;
    }

    public void setTxtUrlVideo(TextView txtUrlVideo) {
        this.txtUrlVideo = txtUrlVideo;
    }

    public TextView getTxtRelacionUniversidad() {
        return txtRelacionUniversidad;
    }

    public void setTxtRelacionUniversidad(TextView txtRelacionUniversidad) {
        this.txtRelacionUniversidad = txtRelacionUniversidad;
    }

    public TextView getTxtEstado() {
        return txtEstado;
    }

    public void setTxtEstado(TextView txtEstado) {
        this.txtEstado = txtEstado;
    }

    public TextView getTxtNumeroVotos() {
        return txtNumeroVotos;
    }

    public void setTxtNumeroVotos(TextView txtNumeroVotos) {
        this.txtNumeroVotos = txtNumeroVotos;
    }

    public Button getBtnIrVideo() {
        return btnIrVideo;
    }

    public void setBtnIrVideo(Button btnIrVideo) {
        this.btnIrVideo = btnIrVideo;
    }

    //Metodos get y set de la aplicacion
}
