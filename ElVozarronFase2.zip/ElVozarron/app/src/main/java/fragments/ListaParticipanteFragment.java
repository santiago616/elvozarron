package fragments;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;

import activity.ListaInicioActivity;
import activity.ParticipanteActivity;
import co.edu.uniquindio.android.electiva.elvozarron.R;
import ulti.AdaptadorDeParticipante;
import vo.Participante;

/**
 * Clase que permite mostrar la lista de los entrenadores en la aplicacion
 * A simple {@link Fragment} subclass.
 */
public class ListaParticipanteFragment extends Fragment implements AdaptadorDeParticipante.OnClickAdaptadorDeParticpante{
    //Declaracion de Atributo de tipo AdaptadorDePersonaje cuyo identificador es adaptador
    AdaptadorDeParticipante adaptador=null;
    //Declaracion de Atributo de tipo RecyclerView cuyo identificador es listadoDePersonajes
    private RecyclerView listadoDeParticipantes;
    //Declaracion de Atributo de tipo ArrayList cuyo identificador es personajes
    private ArrayList<Participante> participantes = new ArrayList();
    //Declaracion de Atributo de tipo OnPersonajeSeleccionadoListener cuyo identificador es listener
    private OnParticipanteSeleccionadoListener listener;

    private TextInputEditText txtIdentificacion;
    private TextInputEditText txtNombre;
    private TextInputEditText txtEdad;
    private TextInputEditText txtUrlVIdeo;
    private TextInputEditText txtRelacionU;
    private TextInputEditText txtEstado;

    /**
     * Metodo Constructor
     */
    public ListaParticipanteFragment() {
        // Required empty public constructor
    }

    /**
     * método que se llama cuando se crea una actividad al igual que los
     * participantes que se quiere q se muestren en la aplicacion
     * @param savedInstanceState
     */
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        participantes = new ArrayList();
        participantes.add(new Participante("123456","Santiago","22","https://www.youtube.com/watch?v=v2cRj9Z96PQ",
                "Estudiante","Activo","22"));

        participantes.add(new Participante("1234567","Alejandra","22","https://www.youtube.com/watch?v=v2cRj9Z96PQ",
                "Estudiante","Activo","22"));

        participantes.add(new Participante("1234568","Alejandro","22","https://www.youtube.com/watch?v=v2cRj9Z96PQ",
                "Estudiante","Activo","22"));

    }

    /**
     * Metodo que se llama cuando se crea una vista y se infla el layout con otro layout
     * el cual es el que se desea mostrar
     * @param inflater inflador con el cual sse desea llenar el layout
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_lista_participante, container, false);
    }

    /**
     * Meteodo que se llama cuando se crea una actividad y de igual forma se llama
     * una nueva actividad la cual permitira mostrar los participantes en la lista
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        listadoDeParticipantes = (RecyclerView)
                getView().findViewById(R.id.fragmento_lista_participantes);
        adaptador = new AdaptadorDeParticipante(participantes,this);
        listadoDeParticipantes.setAdapter(adaptador);
        listadoDeParticipantes.setLayoutManager(
                new LinearLayoutManager(getContext(),
                        LinearLayoutManager.VERTICAL,
                        false));
    }

    /**
     * Metodo que se llama cuando se crea un menu de opciones
     * @param menu menu que se desea mostrar
     * @param inflater inflador con el cual se pretende rellenar el menu
     */
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }

    /**
     * Metodo que se llama cuando se crean opciones de seleccion
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        int id = item.getItemId();
        if (id == R.id.menu_agregar) {


            ((ParticipanteActivity) getActivity()).mostrarDialigoAgregarPersonaje(ListaParticipanteFragment.class.getName());



        } else if (id == R.id.menu_eliminar) {
            participantes.remove(1);
            adaptador.notifyItemRemoved(1);
        } else if (id == R.id.menu_modificar) {
            Participante aux = participantes.get(1);
            participantes.set(1, participantes.get(2));
            participantes.set(2, aux);
            adaptador.notifyItemMoved(1, 2);
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Metodo que permite seleccionar el participante que se presiona con el click
     * por medio de la posision
     * @param pos posición en la que se encuentra el participante
     */
    public void onClickPosition(int pos) {
        listener.onParticipanteSeleccionado(pos);
    }

    /**
     * Metodo que se usa para que se active al seleccionar uno de los
     * participantes que se encuentran en la lista
     */
    public interface OnParticipanteSeleccionadoListener{
        void onParticipanteSeleccionado(int position);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Activity activity;
        if (context instanceof Activity){
            activity = (Activity) context;
            try {
                listener = (OnParticipanteSeleccionadoListener) activity;
            } catch (ClassCastException e) {
                throw new ClassCastException(activity.toString() + " debe implementar la interfaz OnPersonajeSeleccionadoListener");
            }
        }
    }

    //Metodos get y set de la aplicacion
    public AdaptadorDeParticipante getAdaptador() {
        return adaptador;
    }

    public void setAdaptador(AdaptadorDeParticipante adaptador) {
        this.adaptador = adaptador;
    }

    public RecyclerView getListadoDeParticipantes() {
        return listadoDeParticipantes;
    }

    public void setListadoDeParticipantes(RecyclerView listadoDeParticipantes) {
        this.listadoDeParticipantes = listadoDeParticipantes;
    }

    public ArrayList<Participante> getParticipantes() {
        return participantes;
    }

    public void setParticipantes(ArrayList<Participante> participantes) {
        this.participantes = participantes;
    }

    public OnParticipanteSeleccionadoListener getListener() {
        return listener;
    }

    public void setListener(OnParticipanteSeleccionadoListener listener) {
        this.listener = listener;
    }

    public TextInputEditText getTxtIdentificacion() {
        return txtIdentificacion;
    }

    public void setTxtIdentificacion(TextInputEditText txtIdentificacion) {
        this.txtIdentificacion = txtIdentificacion;
    }

    public TextInputEditText getTxtNombre() {
        return txtNombre;
    }

    public void setTxtNombre(TextInputEditText txtNombre) {
        this.txtNombre = txtNombre;
    }

    public TextInputEditText getTxtEdad() {
        return txtEdad;
    }

    public void setTxtEdad(TextInputEditText txtEdad) {
        this.txtEdad = txtEdad;
    }

    public TextInputEditText getTxtUrlVIdeo() {
        return txtUrlVIdeo;
    }

    public void setTxtUrlVIdeo(TextInputEditText txtUrlVIdeo) {
        this.txtUrlVIdeo = txtUrlVIdeo;
    }

    public TextInputEditText getTxtRelacionU() {
        return txtRelacionU;
    }

    public void setTxtRelacionU(TextInputEditText txtRelacionU) {
        this.txtRelacionU = txtRelacionU;
    }

    public TextInputEditText getTxtEstado() {
        return txtEstado;
    }

    public void setTxtEstado(TextInputEditText txtEstado) {
        this.txtEstado = txtEstado;
    }
    //Metodos get y set de la aplicacion



    public void agregarParticipante()
    {

        String identi,nombre,edad,urlvideo,relacionU,estado;


        txtIdentificacion= (TextInputEditText) getView().findViewById(R.id.identificacionDialogo);
        identi= String.valueOf(txtIdentificacion.getText());

        txtNombre=(TextInputEditText)getView().findViewById(R.id.nombreDialogo);
        nombre=String.valueOf(txtNombre.getText());

        txtEdad=(TextInputEditText)getView().findViewById(R.id.edadDialogo);
        edad=String.valueOf(txtEdad.getText());

        txtUrlVIdeo=(TextInputEditText)getView().findViewById(R.id.urlVIdeoDialogo);
        urlvideo=String.valueOf(txtUrlVIdeo.getText());

        txtRelacionU=(TextInputEditText)getView().findViewById(R.id.relacionUDialogo);
        relacionU=String.valueOf(txtRelacionU.getText());

        txtEstado=(TextInputEditText)getView().findViewById(R.id.estadoDialogo);
        estado=String.valueOf(txtEstado.getText());


        participantes.add(new Participante(identi,nombre,edad,urlvideo,relacionU,estado,"22"));
        adaptador.notifyItemInserted(1);
    }
}
