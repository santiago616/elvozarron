package fragments;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;

import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import co.edu.uniquindio.android.electiva.elvozarron.R;
import ulti.AdaptadorDeEntrenador;
import vo.Entrenador;


/**
 * Clase que permite mostrar la lista de los entrenadores en la aplicacion
 * A simple {@link Fragment} subclass.
 */
public class ListaEntrenadorFragment extends Fragment implements AdaptadorDeEntrenador.OnClickAdaptadorDeEntrenador {

    //Declaracion de Atributo de tipo AdaptadorDePersonaje cuyo identificador es adaptador
    AdaptadorDeEntrenador adaptador=null;
    //Declaracion de Atributo de tipo RecyclerView cuyo identificador es listadoDePersonajes
    private RecyclerView listadoDeEntrenadores;
    //Declaracion de Atributo de tipo ArrayList cuyo identificador es personajes
    private ArrayList<Entrenador> entrenadores = new ArrayList();
    //Declaracion de Atributo de tipo OnPersonajeSeleccionadoListener cuyo identificador es listener
    private OnEntrenadorSeleccionadoListener listener;

    /**
     * Metodo constructor de la clase
     */
    public ListaEntrenadorFragment() {
        // Required empty public constructor
    }



    /**
     * método que se llama cuando se crea una actividad y en el cual se agregan
     * los entrenadores que se desea visualizar en la apliccion
     * @param savedInstanceState
     */
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        entrenadores = new ArrayList();
        entrenadores.add(new Entrenador("123456","Rihanna","Femenino","artista"));
        entrenadores.add(new Entrenador("1234567","Jhony Rivera","Masculino","artista"));
        entrenadores.add(new Entrenador("1234568","Adele","Femenino","artista"));

    }

    /**
     * Meteodo que se llama cuando se crea una actividad
     * en el cual se llama y se crea otra actividad instanciada que
     * permitira visualizar cada uno de los entrenadores
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        listadoDeEntrenadores = (RecyclerView)
                getView().findViewById(R.id.fragmento_lista_entrenadores);
        adaptador = new AdaptadorDeEntrenador(entrenadores,this);
        listadoDeEntrenadores.setAdapter(adaptador);
        listadoDeEntrenadores.setLayoutManager(
                new LinearLayoutManager(getContext(),
                        LinearLayoutManager.VERTICAL,
                        false));
    }

    /**
     * Metodo que permite crear la vista por metodo de un inflador de layout
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_lista_entrenador, container, false);
    }

    /**
     * Metodo que se usa para que se active al seleccionar uno de los
     * entrenadores que se encuentran en la lista
     */
    public interface OnEntrenadorSeleccionadoListener{
        void onEntrenadorSeleccionado(int position);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Activity activity;
        if (context instanceof Activity){
            activity = (Activity) context;
            try {
                listener = (OnEntrenadorSeleccionadoListener) activity;
            } catch (ClassCastException e) {
                throw new ClassCastException(activity.toString() + " debe implementar la interfaz OnPersonajeSeleccionadoListener");
            }
        }
    }

    /**
     * Metodo que permite seleccionar el entrenador que se presiona con el click
     * por medio de la posision
     * @param pos posición en la cual se encuentra el entrenador
     */
    @Override
    public void onClickPosition(int pos) {
    listener.onEntrenadorSeleccionado(pos);
    }

    //Metodos get y set de la aplicaicon

    public AdaptadorDeEntrenador getAdaptador() {
        return adaptador;
    }

    public void setAdaptador(AdaptadorDeEntrenador adaptador) {
        this.adaptador = adaptador;
    }

    public RecyclerView getListadoDeEntrenadores() {
        return listadoDeEntrenadores;
    }

    public void setListadoDeEntrenadores(RecyclerView listadoDeEntrenadores) {
        this.listadoDeEntrenadores = listadoDeEntrenadores;
    }

    public ArrayList<Entrenador> getEntrenadores() {
        return entrenadores;
    }

    public void setEntrenadores(ArrayList<Entrenador> entrenadores) {
        this.entrenadores = entrenadores;
    }

    public OnEntrenadorSeleccionadoListener getListener() {
        return listener;
    }

    public void setListener(OnEntrenadorSeleccionadoListener listener) {
        this.listener = listener;
    }

    //Metodos get y set de la aplicaicon

}
