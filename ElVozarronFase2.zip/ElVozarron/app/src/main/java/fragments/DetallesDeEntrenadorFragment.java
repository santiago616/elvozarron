package fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import co.edu.uniquindio.android.electiva.elvozarron.R;
import vo.Entrenador;


/**
 * Clase que permite mostrar los detalles de los entrenadores en la aplicacion
 * A simple {@link Fragment} subclass.
 */
public class DetallesDeEntrenadorFragment extends Fragment {

    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtIdentificacion;

    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtNombre;

    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtGenero;

    //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombre
    private TextView txtHistorial;
    //Declaracion del atributo de tipo Entrenador cuyo identificador es entrenador
    private Entrenador entrenador;
    //Declaracion del atributo de tipo ImageView cuyo identificador es imagen
    private ImageView imagen;


    /**
     * Metodo constructor de la clase
     */
    public DetallesDeEntrenadorFragment() {
        // Required empty public constructor
    }

    /**
     * Metodo que crea la vista al inicializarce esta actividad
     * @param inflater parametro que permite inflar el layout con el layout que se quiere mostrar
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detalles_de_entrenador, container, false);
    }


    /**
     * Metodo que muestra todos los datos del entrenador en pantalla en las cajas de texto
     * al igual que la imagen de cada uno de ellos
     * @param entrenador entrenador que se desea visualizar
     */
    public void mostrarEntrenador (Entrenador entrenador) {
        this.entrenador = entrenador;

        txtIdentificacion = (TextView)
                getView().findViewById(R.id.identificacion_entrenador);
        txtIdentificacion.setText("Identificacion: "+entrenador.getIdentificacion());


        txtNombre = (TextView)
                getView().findViewById(R.id.nombre_entrenador);
        txtNombre.setText("Nombre: "+entrenador.getNombre());

        txtGenero = (TextView)
                getView().findViewById(R.id.genero_entrenador);
        txtGenero.setText("Genero: "+entrenador.getGenero());

        txtHistorial = (TextView)
                getView().findViewById(R.id.historial_entrenador);
        txtHistorial.setText("Historial: "+entrenador.getHistorial());

        if(entrenador.getNombre().equals("Rihanna"))
        {
            imagen=(ImageView)getView().findViewById(R.id.imagen_detalle);

            imagen.setImageResource(R.drawable.rihana);
        }else
        if(entrenador.getNombre().equals("Jhony Rivera"))
        {
            imagen=(ImageView)getView().findViewById(R.id.imagen_detalle);
            imagen.setImageResource(R.drawable.jhony);
        }else
        {
            imagen=(ImageView)getView().findViewById(R.id.imagen_detalle);
            imagen.setImageResource(R.drawable.adele);
        }


    }

    //Metodos get y set de la aplicacion

    public TextView getTxtIdentificacion() {
        return txtIdentificacion;
    }

    public void setTxtIdentificacion(TextView txtIdentificacion) {
        this.txtIdentificacion = txtIdentificacion;
    }

    public TextView getTxtNombre() {
        return txtNombre;
    }

    public void setTxtNombre(TextView txtNombre) {
        this.txtNombre = txtNombre;
    }

    public TextView getTxtGenero() {
        return txtGenero;
    }

    public void setTxtGenero(TextView txtGenero) {
        this.txtGenero = txtGenero;
    }

    public TextView getTxtHistorial() {
        return txtHistorial;
    }

    public void setTxtHistorial(TextView txtHistorial) {
        this.txtHistorial = txtHistorial;
    }

    public Entrenador getEntrenador() {
        return entrenador;
    }

    public void setEntrenador(Entrenador entrenador) {
        this.entrenador = entrenador;
    }

    public ImageView getImagen() {
        return imagen;
    }

    public void setImagen(ImageView imagen) {
        this.imagen = imagen;
    }
    //Metodos get y set de la aplicacion

}
