package activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import co.edu.uniquindio.android.electiva.elvozarron.R;

/**
 * Clase principal que se ha creado para inicializar la actividad de Inicio de la aplicacion
 */
public class InicioActivity extends AppCompatActivity {

    /**
     * método que se llama cuando se crea una actividad
     * @param savedInstanceState
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        abrirListaInicio();
    }

    /**
     * metodo que se crea para que al presionar el boton creado se ingrese a la lista de inicio
     */
    public void abrirListaInicio()
    {
        Button entrar = (Button) findViewById(R.id.button);
        //hago clic y se abre el 2
        entrar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent lista = new Intent(getApplicationContext(), ListaInicioActivity.class);
                startActivity(lista);
            }
        });
    }
}
