package activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import co.edu.uniquindio.android.electiva.elvozarron.R;
import fragments.DetallesDeEntrenadorFragment;
import fragments.ListaEntrenadorFragment;


/**
 * Clase principal que se ha creado para inicializar la actividad del entrenador
 */
public class EntrenadorActivity extends AppCompatActivity implements ListaEntrenadorFragment.OnEntrenadorSeleccionadoListener {

    /*
    Instancia del fragmento ListaEntrenadorFragment
     */
    ListaEntrenadorFragment listaEntrenadorFragment;
    /**
     * método que se llama cuando se crea una actividad
     * @param savedInstanceState
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entrenador);

        listaEntrenadorFragment =
                (ListaEntrenadorFragment)
                        getSupportFragmentManager().findFragmentById(R.id.fragmento_lista_entrenadores);
        listaEntrenadorFragment.setEntrenadores(listaEntrenadorFragment.getEntrenadores());

    }

    /**
     * Metodo creado para conocer el entrenador que se selecciona y posterior a eso abrir los detalles de ese entrenador
     * @param position en la que se encuentra el entranador selecionado
     */
    @Override
    public void onEntrenadorSeleccionado(int position) {
        boolean esFragmento =
                getSupportFragmentManager().findFragmentById(R.id.fragmento_detalle_entrenador) != null;
        if (esFragmento) {
            ((DetallesDeEntrenadorFragment)
                    getSupportFragmentManager().findFragmentById(R.id.fragmento_detalle_entrenador)).
                    mostrarEntrenador(listaEntrenadorFragment.getEntrenadores().get(position));
        } else {
            Intent intent = new Intent(this,
                    DetalleDeEntrenadorActivity.class);
            intent.putExtra("ent", listaEntrenadorFragment.getEntrenadores().get(position));
            startActivity(intent);
        }
    }


}
