package activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import co.edu.uniquindio.android.electiva.elvozarron.R;
import ulti.AddaptadorListaInicio;

/**
 * Clase Principal que se ha creado para mostrar la lista de inicio de la aplicacion
 * Created by santiago on 24/10/16.
 */
public class ListaInicioActivity extends AppCompatActivity {

    /*
    Se inicializa uns lista de tipo ListView
     */
    ListView lista;
    /*
    Se inicializa un arreglo de personas de tipo String
     */
    String[] personas = {
            "Entrenadores",
            "Participantes",
            "Votaciones",

    };

    /*
    Se inicializa un arreglo de imagenes de tipo Integer
     */
    private Integer[] imgid={
            R.drawable.entrenador,
            R.drawable.participantes,
            R.drawable.votar,

    };

    /**
     * método que se llama cuando se crea una actividad
     * @param savedInstanceState
     */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_inicio);

        AddaptadorListaInicio adapter=new AddaptadorListaInicio(this,personas,imgid);
        lista=(ListView)findViewById(R.id.miLista);
        lista.setAdapter(adapter);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView adapterView, View view, int posicion, long l) {
                //Toast.makeText(getApplicationContext(), "posicion " + (i + 1) + personas[i], Toast.LENGTH_SHORT).show();
                switch (posicion) {
                    case 0 :
                        Intent i = new Intent(getApplicationContext(), EntrenadorActivity.class);
                        startActivity(i);
                        break;
                    case 1 :
                        Intent ii = new Intent(getApplicationContext(), ParticipanteActivity.class);
                        startActivity(ii);
                        break;
                    default:
                        Intent iii = new Intent(getApplicationContext(), ParticipanteActivity.class);
                        startActivity(iii);
                        break;
                }
            }
        });
    }

    }
