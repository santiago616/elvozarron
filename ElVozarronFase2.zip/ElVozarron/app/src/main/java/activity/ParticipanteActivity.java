package activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import co.edu.uniquindio.android.electiva.elvozarron.R;

import fragments.AgregarParticipanteFragment;
import fragments.DetallesDeParticipanteFragment;
import fragments.ListaParticipanteFragment;


/**
 * Clase principal que se ha creado para inicializar la actividad del entrenador
 *Created by santiago on 24/10/16.
 */
public class ParticipanteActivity extends AppCompatActivity implements ListaParticipanteFragment.OnParticipanteSeleccionadoListener {

    /*
   Instancia del fragmento ListaParticipanteFragment
    */
    ListaParticipanteFragment listaParticipanteFragment;

    /**
     * método que se llama cuando se crea una actividad
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participante);
        listaParticipanteFragment =
                (ListaParticipanteFragment)
                        getSupportFragmentManager().findFragmentById(R.id.fragmento_lista_participantes);
        listaParticipanteFragment.setParticipantes(listaParticipanteFragment.getParticipantes());
    }

    /**
     * Metodo creado para conocer el participante que se selecciona y posterior a eso abrir los detalles de ese participante
     * @param position en la que se encuentra el participante selecionado
     */
    @Override
    public void onParticipanteSeleccionado(int position) {
        boolean esFragmento =
                getSupportFragmentManager().findFragmentById(R.id.fragmento_detalle_participante) != null;
        if (esFragmento) {
            ((DetallesDeParticipanteFragment)
                    getSupportFragmentManager().findFragmentById(R.id.fragmento_detalle_participante)).mostrarParticipante(listaParticipanteFragment.getParticipantes().get(position));
        } else {
            Intent intent = new Intent(this,
                    DetalleDeParticipanteActivity.class);
            intent.putExtra("par", listaParticipanteFragment.getParticipantes().get(position));
            startActivity(intent);
        }
    }

    /**
     * Metodo que crea el menu en la lista de los participantes
     * @param menu el menu que aparecera en el layout
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    /**
     * Metodo que crea los items del menu
     * @param item items que apareceran dentro del menu
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }


    public void mostrarDialigoAgregarPersonaje(String nombreClase) {
        AgregarParticipanteFragment dialogAgreParticipante = new AgregarParticipanteFragment();
        Button entrar = (Button) findViewById(R.id.botonAgregar);
        dialogAgreParticipante.setStyle(dialogAgreParticipante.STYLE_NORMAL, R.style.DialogoTitulo);
        dialogAgreParticipante.show(getSupportFragmentManager(), nombreClase);



    }

}
