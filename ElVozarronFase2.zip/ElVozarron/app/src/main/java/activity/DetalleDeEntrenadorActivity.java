package activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import co.edu.uniquindio.android.electiva.elvozarron.R;
import fragments.DetallesDeEntrenadorFragment;
import vo.Entrenador;


/**
 * Clase Principal que se ha creado para mostrar los detalles de cada entrenador
 * Created by santiago on 24/10/16.
 */
public class DetalleDeEntrenadorActivity extends AppCompatActivity {
    /**
     * método que se llama cuando se crea una actividad
     * @param savedInstanceState
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_de_entrenador);

        DetallesDeEntrenadorFragment detallesDeEntrenadorFragment =(DetallesDeEntrenadorFragment)
                getSupportFragmentManager().findFragmentById(R.id.fragmento_detalle_entrenador);
        Entrenador entrenador = (Entrenador) getIntent().getExtras().get("ent");
        detallesDeEntrenadorFragment.mostrarEntrenador(entrenador);
    }
}
