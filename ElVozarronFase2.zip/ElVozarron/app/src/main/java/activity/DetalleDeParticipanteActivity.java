package activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import co.edu.uniquindio.android.electiva.elvozarron.R;

import fragments.DetallesDeParticipanteFragment;
import vo.Participante;


/**
 * Clase Principal que se ha creado para mostrar los detalles de cada participante
 * Created by santiago on 24/10/16.
 */
public class DetalleDeParticipanteActivity extends AppCompatActivity {

    /**
     * método que se llama cuando se crea una actividad
     * @param savedInstanceState
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_de_participante);

        DetallesDeParticipanteFragment detalleParticipante =(DetallesDeParticipanteFragment)
                getSupportFragmentManager().findFragmentById(R.id.fragmento_detalle_participante);
        Participante participante = (Participante) getIntent().getExtras().get("par");
        detalleParticipante.mostrarParticipante(participante);
    }

}
