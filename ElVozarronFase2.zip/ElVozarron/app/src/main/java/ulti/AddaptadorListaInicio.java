package ulti;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import co.edu.uniquindio.android.electiva.elvozarron.R;

/**
 * Clase que permite mostrar la informacion de cada uno de los items de la lista de inicio
 * Created by santiago on 25/10/16.
 */
public class AddaptadorListaInicio  extends ArrayAdapter<String> {

    //Declaracion de Atributo de tipo Activity cuyo identificador es context
    private final Activity context;
    //Declaracion de Atributo de tipo String cuyo identificador es itemname
    private final String[] itemname;
    //Declaracion de Atributo de tipo Integer cuyo identificador es integers
    private final Integer[] integers;

    /**
     * Metodo constructor de la clase
     * @param context instancia de la actividad
     * @param itemname instancia del arreglo de nombres
     * @param integers instancia del arreglo de la identificacion de la imagen
     */
    public AddaptadorListaInicio(Activity context, String[] itemname, Integer[] integers) {
        super(context, R.layout.fila_lista, itemname);
        // TODO Auto-generated constructor stub

        this.context=context;
        this.itemname=itemname;
        this.integers=integers;
    }

    /**
     * Metodo por el cual se infla el layout con la informacion que se envia al layout desde aqui
     * @param posicion posision en la que se encuentra el item al cual s ele desea enviar la informacion
     * @param view vista que se desea inflar
     * @param parent
     * @return
     */
    public View getView(int posicion, View view, ViewGroup parent){

        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.fila_lista,null,true);

        TextView txtTitle = (TextView) rowView.findViewById(R.id.texto_principal);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);


        txtTitle.setText(itemname[posicion]);
        imageView.setImageResource(integers[posicion]);


        return rowView;
    }
}
