package ulti;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import co.edu.uniquindio.android.electiva.elvozarron.R;
import fragments.ListaParticipanteFragment;
import vo.Participante;

/**
 * Created by santiago on 23/10/16.
 * Clase que permite mostrar la informacion en del participante en la lista de entrenadores
 */
public class AdaptadorDeParticipante extends RecyclerView.Adapter<AdaptadorDeParticipante.ParticipanteViewHolder> {


    //Declaracion de Atributo de tipo Arraylist cuyo identificador es participantes
    private ArrayList<Participante> participantes = new ArrayList();
    //Declaracion de Atributo de tipo OnClickAdaptadorDePersonaje cuyo identificador es listener
    private static OnClickAdaptadorDeParticpante listener;

    /**
     * Metodo Constructor de la clase
     * @param participantes lista de participantes
     * @param listaParticipanteFragment lista de participantes fragment
     */
    public AdaptadorDeParticipante(ArrayList<Participante> participantes,
                                   ListaParticipanteFragment listaParticipanteFragment) {
        this.participantes = participantes;
        listener = (OnClickAdaptadorDeParticpante)
                listaParticipanteFragment;
    }

    /**
     * Metodo entrenadoresViewHolder el cual permite mostrar la informacion del participante
     * en la lista de entrenadores
     */
    public static class ParticipanteViewHolder
            extends RecyclerView.ViewHolder implements View.OnClickListener {
        //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombreParticipante
        private TextView txtNombreParticipante;

        //Metodo que permite mostrar cada uno de los items de los participantes
        // con su respectivo nombre
        public ParticipanteViewHolder(View itemView) {
            super(itemView);

            itemView.setOnClickListener(this);
            txtNombreParticipante = (TextView)
                    itemView.findViewById(R.id.nombre_participante_resumen);


        }

        /**
         * Metodo binParticpante por medio de este metodo podemos enviar
         * el nombre de cada participante
         * @param participante personaje el cual se va visualizar
         */
        public void binParticpante(Participante participante) {
            txtNombreParticipante.setText(participante.getNombre());


        }

        /**
         * Metodo que se ejecuta al hacer click y envia la posicion en la que se encuentra cada
         * participante en la lista
         * @param v vista a mostrar
         */
        @Override
        public void onClick(View v) {
            Log.d("TAG", "Element " + getAdapterPosition() + " clicked. "+
                    txtNombreParticipante.getText());

            listener.onClickPosition(getAdapterPosition());
        }
    }

    /**
     * Metodo que devuelve ParticipanteViewHolder al crearse la vista del participante
     * @param parent
     * @param viewType
     * @return
     */
    @Override
    public ParticipanteViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.resumen_participante, parent, false);
        ParticipanteViewHolder participanteVH = new
                ParticipanteViewHolder(itemView);
        return participanteVH;
    }

    @Override
    public void onBindViewHolder(ParticipanteViewHolder holder, int position) {
        Participante participante = participantes.get(position);
        holder.binParticpante(participante);
    }

    /**
     * Metodo que muestra el numero de participantes
     * @return numero de personajes
     */
    @Override
    public int getItemCount() {
        return participantes.size();
    }

    public interface OnClickAdaptadorDeParticpante{
        public void onClickPosition(int pos);
    }
}
