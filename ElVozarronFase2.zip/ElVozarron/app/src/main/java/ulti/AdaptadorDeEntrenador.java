package ulti;

import android.media.Image;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import co.edu.uniquindio.android.electiva.elvozarron.R;
import fragments.ListaEntrenadorFragment;
import vo.Entrenador;



/**
 * Clase que permite mostrar la informacion en del entrenador en la lista de entrenadores
 * Created by santiago on 25/10/16.
 */
public class AdaptadorDeEntrenador extends RecyclerView.Adapter<AdaptadorDeEntrenador.EntrenadorViewHolder> {

    //Declaracion de Atributo de tipo ArrayList cuyo identificador es entrenadores
    private ArrayList<Entrenador> entrenadores = new ArrayList();
    //Declaracion de Atributo de tipo ImageView cuyo identificador es imagen
    private ImageView imagen;
    //Declaracion de Atributo de tipo OnClickAdaptadorDeEntrenador cuyo identificador es listener
    private static OnClickAdaptadorDeEntrenador listener;

    /**
     * Metodo Constructor de la clase
     *
     * @param entrenadores             lista de entrenadores
     * @param listaEntrenadorFragment lista de entrenadores fragment
     */
    public AdaptadorDeEntrenador(ArrayList<Entrenador> entrenadores,
                                 ListaEntrenadorFragment listaEntrenadorFragment) {
        this.entrenadores = entrenadores;
        listener = (OnClickAdaptadorDeEntrenador)
                listaEntrenadorFragment;
    }

    /**
     * Metodo entrenadoresViewHolder el cual permite mostrar la informacion del entrenador
     * en la lista de entrenadores
     */
    public static class EntrenadorViewHolder
            extends RecyclerView.ViewHolder implements View.OnClickListener {
        //Declaracion de Atributo de tipo TextView cuyo identificador es txtNombreEntrenador
        private TextView txtNombreEntrenador;
        //Declaracion de Atributo de tipo ImageView cuyo identificador es imagen
        private ImageView imagen;

       //Metodo que permite mostrar cada uno de los items de los entrenadores
       // con su respectivaimagen y su respectivo nombre
        public EntrenadorViewHolder(View itemView) {
            super(itemView);

            itemView.setOnClickListener(this);
            txtNombreEntrenador = (TextView)
                    itemView.findViewById(R.id.nombre_entreador_resumen);

        imagen=(ImageView)itemView.findViewById(R.id.imagen_resumen_entrenador);
        }

        /**
         * Metodo binentrenadores por medio de este metodo podemos enviar
         * el nombre de cada entrenador y su respectiva imagen
         *
         * @param entrenador entrenadores el cual se va visualizar
         */
        public void binEntrenador(Entrenador entrenador) {
            txtNombreEntrenador.setText(entrenador.getNombre());

            if(entrenador.getNombre().equals("Rihanna"))
            {
                imagen.setImageResource(R.drawable.rihana);
            }else
            if(entrenador.getNombre().equals("Jhony Rivera"))
            {
                imagen.setImageResource(R.drawable.jhony);
            }else
            {

                    imagen.setImageResource(R.drawable.adele);

            }
        }

        /**
         * Metodo que se ejecuta al hacer click y envia la posicion en la que se encuentra cada
         * entrenador en la lista
         *
         * @param v vista a mostrar
         */
        @Override
        public void onClick(View v) {
            Log.d("TAG", "Element " + getAdapterPosition() + " clicked. " +
                    txtNombreEntrenador.getText());

            listener.onClickPosition(getAdapterPosition());
        }
    }

    /**
     * Metodo que devuelve entrenadoresViewHolder al crearse la vista del entrenadores
     *
     * @param parent
     * @param viewType
     * @return
     */
    @Override
    public EntrenadorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.resumen_entrenador, parent, false);
        EntrenadorViewHolder entrenadorVH = new
                EntrenadorViewHolder(itemView);
        return entrenadorVH;
    }

    @Override
    public void onBindViewHolder(EntrenadorViewHolder holder, int position) {
        Entrenador entrenador = entrenadores.get(position);
        holder.binEntrenador(entrenador);
    }

    /**
     * Metodo que muestra el numero de entrenadores
     *
     * @return numero de entrenadores
     */
    @Override
    public int getItemCount() {
        return entrenadores.size();
    }

    public interface OnClickAdaptadorDeEntrenador {
        public void onClickPosition(int pos);
    }

    //Metodos get y set de la aplicacion
    public ImageView getImagen() {
        return imagen;
    }

    public void setImagen(ImageView imagen) {
        this.imagen = imagen;
    }
    //Metodos get y set de la aplicacion
}